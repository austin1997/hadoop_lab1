package edu.rosehulman.zhaiz;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * TODO Put here a description of what this class does.
 *
 * @author zhaiz.
 *         Created 2017/09/12.
 */
public class MinTemperatureMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	private static final int MISSING = 9999;

	@Override
	public void map(LongWritable key, Text value, Context context) throws 
	IOException,InterruptedException{

		String line = value.toString();
		//Reading just the data we are interested in
		String year = line.substring(15,19);
		int airTemperature;

		if(line.charAt(87) =='+'){
			airTemperature = Integer.parseInt(line.substring(88,92));
		}
		else{
			airTemperature = Integer.parseInt(line.substring(87,92));
		}

		String quality = line.substring(92,93);

		if (airTemperature!=MISSING && quality.matches("[01459]")){
			//write output key value
			context.write(new Text(year), new IntWritable(airTemperature));
		}
	}
}
